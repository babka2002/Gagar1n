Gothic №60 is a font inspired by Lining Gothic №60 by Chicago, Barnhart Bros. & Spindler (1907) and unicase font on the cover of a Soviet photo magazine.

The font is free for commercial use 
I will be glad if you share your projects with my font

https://www.behance.net/alinamolchanova